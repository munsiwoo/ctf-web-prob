<?php
error_reporting(0);

define('__DB__', $_SERVER['DOCUMENT_ROOT'].'/config/database.db');
